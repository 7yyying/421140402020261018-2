# 小橋攝影工作室 作品集網站

單頁靜態網站（純 HTML + CSS，只有一小段表單 JavaScript），可直接上傳 GitHub 並用 Vercel 部署。

## 檔案結構

```
.
├── index.html      # 全站（HTML + CSS 皆在此檔）
├── images/         # 作品圖片（目前為示意佔位圖）
└── README.md
```

## 換成真正的照片

`images/` 內目前是程式產生的佔位圖，檔名已與 `index.html` 對應，直接用同檔名覆蓋即可：

- `wedding-01.jpg` ~ `wedding-06.jpg`：婚紗
- `ceremony-01.jpg` ~ `ceremony-06.jpg`：婚禮紀錄
- `portrait-01.jpg` ~ `portrait-06.jpg`：形象照
- `about.jpg`：關於我（建議 4:5 直式）
- `hero.jpg`：首頁大圖（建議 1920×1080 橫式）

免費圖庫（可商用，請再次確認各張授權）：[Unsplash](https://unsplash.com)、[Pexels](https://www.pexels.com)、[Pixabay](https://pixabay.com)。
建議作品圖寬 1200px 以內、單檔小於 300 KB，載入會更快。
換圖後記得同步修改 `alt` 文字，讓描述符合實際畫面。

## 上線前請修改

在 `index.html` 搜尋並替換：

| 項目 | 目前值 |
|------|--------|
| Email | `hello@example.com` |
| Instagram | `your_account` |
| 網址 | `https://your-project.vercel.app/`（`<link rel="canonical">`） |
| 價格與案例 | 皆為示意內容 |

詢問表單目前以 `mailto:` 開啟使用者的郵件程式。若想直接收到表單內容，可改用 Formspree、Google Forms 或 Vercel Serverless Function。

## 部署到 GitHub + Vercel

```bash
git init
git add .
git commit -m "Initial portfolio site"
git branch -M main
git remote add origin https://github.com/<你的帳號>/<repo 名稱>.git
git push -u origin main
```

1. 登入 [vercel.com](https://vercel.com)，選 **Add New → Project**。
2. 匯入剛建立的 GitHub repo。
3. Framework Preset 選 **Other**，不需要 Build Command，Output Directory 留空。
4. 按 **Deploy**，完成後會得到網址；之後每次 push 到 `main` 都會自動更新。
